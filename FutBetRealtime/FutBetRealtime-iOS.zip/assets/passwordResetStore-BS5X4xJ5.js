import{P as t}from"./index-eTD2MKy5.js";const o=t(e=>({token:null,expiresAt:null,begin:(l,r)=>e({token:l,expiresAt:r}),clear:()=>e({token:null,expiresAt:null})}));export{o as u};
