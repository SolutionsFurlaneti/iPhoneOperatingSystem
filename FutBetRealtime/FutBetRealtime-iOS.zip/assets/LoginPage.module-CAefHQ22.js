const o="_page_1opxj_1",t="_title_1opxj_7",_="_form_1opxj_13",r="_field_1opxj_18",e="_formError_1opxj_45",f="_alt_1opxj_55",l={page:o,title:t,form:_,field:r,formError:e,alt:f};export{l as f};
