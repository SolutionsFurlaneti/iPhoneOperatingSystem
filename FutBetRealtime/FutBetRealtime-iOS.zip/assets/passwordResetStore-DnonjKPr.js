import{R as t}from"./index-bm_CkJRw.js";const o=t(e=>({token:null,expiresAt:null,begin:(l,r)=>e({token:l,expiresAt:r}),clear:()=>e({token:null,expiresAt:null})}));export{o as u};
