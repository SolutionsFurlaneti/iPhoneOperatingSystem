const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DjZ8F7GF.js","assets/index-BB8rq6Q9.js","assets/react-DQarAtJJ.js","assets/charts-DckikGU3.js","assets/index-yY4fBUjX.css"])))=>i.map(i=>d[i]);
import{G as e,_ as r}from"./index-BB8rq6Q9.js";import"./react-DQarAtJJ.js";import"./charts-DckikGU3.js";const _=e("App",{web:()=>r(()=>import("./web-DjZ8F7GF.js"),__vite__mapDeps([0,1,2,3,4])).then(p=>new p.AppWeb)});export{_ as App};
//# sourceMappingURL=index-CXA-UDBd.js.map
