import{j as t}from"./index-CLjnIhAG.js";function r({status:s,label:a}){return t.jsxs("span",{className:"status-badge status-"+s.toLowerCase(),"data-testid":"status-"+s,children:[t.jsx("span",{"aria-hidden":"true"}),a]})}export{r as S};
//# sourceMappingURL=StatusBadge-dB47Cx-s.js.map
