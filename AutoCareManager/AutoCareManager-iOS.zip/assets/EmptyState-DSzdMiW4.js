import{i as n,u as i,j as t}from"./index-CHRx0u_s.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=n("Inbox",[["polyline",{points:"22 12 16 12 14 15 10 15 8 12 2 12",key:"o97t9d"}],["path",{d:"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",key:"oot6mr"}]]);function p({title:s="Tudo pronto para começar",description:a,action:o}){const{t:e}=i();return t.jsxs("div",{className:"empty-state","data-testid":"empty-state",children:[t.jsx("span",{className:"empty-icon",children:t.jsx(r,{size:26})}),t.jsx("h3",{children:e(s)}),t.jsx("p",{children:e(a)}),o]})}export{p as E};
//# sourceMappingURL=EmptyState-DSzdMiW4.js.map
