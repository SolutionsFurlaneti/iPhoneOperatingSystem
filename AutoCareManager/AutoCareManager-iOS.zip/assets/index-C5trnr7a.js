const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-p0WoZwQI.js","assets/index-CJVkzrRt.js","assets/react-DQarAtJJ.js","assets/charts-B9F2n_6F.js","assets/index-BY21AHvt.css"])))=>i.map(i=>d[i]);
import{G as e,aZ as r}from"./index-CJVkzrRt.js";import"./react-DQarAtJJ.js";import"./charts-B9F2n_6F.js";const _=e("App",{web:()=>r(()=>import("./web-p0WoZwQI.js"),__vite__mapDeps([0,1,2,3,4])).then(p=>new p.AppWeb)});export{_ as App};
//# sourceMappingURL=index-C5trnr7a.js.map
