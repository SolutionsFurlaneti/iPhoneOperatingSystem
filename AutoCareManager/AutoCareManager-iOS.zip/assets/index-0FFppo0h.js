const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Bl1Y5vAU.js","assets/index-CjtrZk_g.js","assets/react-4hzvzZwm.js","assets/charts-rr1YMDgM.js","assets/index-DD90NNw4.css"])))=>i.map(i=>d[i]);
import{aS as e,aT as r}from"./index-CjtrZk_g.js";import"./react-4hzvzZwm.js";import"./charts-rr1YMDgM.js";const _=e("App",{web:()=>r(()=>import("./web-Bl1Y5vAU.js"),__vite__mapDeps([0,1,2,3,4])).then(p=>new p.AppWeb)});export{_ as App};
//# sourceMappingURL=index-0FFppo0h.js.map
