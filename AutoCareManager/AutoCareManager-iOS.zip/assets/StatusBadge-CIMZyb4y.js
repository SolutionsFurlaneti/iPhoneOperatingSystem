import{j as t}from"./index-CJVkzrRt.js";function r({status:s,label:a}){return t.jsxs("span",{className:"status-badge status-"+s.toLowerCase(),"data-testid":"status-"+s,children:[t.jsx("span",{"aria-hidden":"true"}),a]})}export{r as S};
//# sourceMappingURL=StatusBadge-CIMZyb4y.js.map
