import{S as n}from"./dialogs-C80wueXW.js";async function u(t,o,r="Confirmar"){return(await n.fire({title:t,text:o,icon:"question",showCancelButton:!0,confirmButtonText:r,cancelButtonText:"Voltar",reverseButtons:!0,focusCancel:!0,customClass:{popup:"confirm-popup"}})).isConfirmed}export{u as c};
//# sourceMappingURL=swal-CGpkzQv0.js.map
