import{h as i,j as e,f as n,m as p,r as m,q as y,i as l,g as d,d as g}from"./index-5CMBOala.js";import{C as f}from"./credit-card-ReXSm9NF.js";import{A as x}from"./activity-BlJUJBiM.js";import{r as v}from"./react-4hzvzZwm.js";import{S as b}from"./StatusBadge-DOpSKS4Z.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=i("Bot",[["path",{d:"M12 8V4H8",key:"hb8ula"}],["rect",{width:"16",height:"12",x:"4",y:"8",rx:"2",key:"enze0r"}],["path",{d:"M2 14h2",key:"vft8re"}],["path",{d:"M20 14h2",key:"4cs60a"}],["path",{d:"M15 13v2",key:"1xurst"}],["path",{d:"M9 13v2",key:"rq6x2g"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const j=i("KeyRound",[["path",{d:"M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",key:"1s6t7t"}],["circle",{cx:"16.5",cy:"7.5",r:".5",fill:"currentColor",key:"w0ekpg"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const S=i("ScanSearch",[["path",{d:"M3 7V5a2 2 0 0 1 2-2h2",key:"aa7l1z"}],["path",{d:"M17 3h2a2 2 0 0 1 2 2v2",key:"4qcy5o"}],["path",{d:"M21 17v2a2 2 0 0 1-2 2h-2",key:"6vwrx8"}],["path",{d:"M7 21H5a2 2 0 0 1-2-2v-2",key:"ioqczr"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}],["path",{d:"m16 16-1.9-1.9",key:"1dq9hf"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=i("Settings2",[["path",{d:"M20 7h-9",key:"3s1dr2"}],["path",{d:"M14 17H5",key:"gfn3mx"}],["circle",{cx:"17",cy:"17",r:"3",key:"18b49y"}],["circle",{cx:"7",cy:"7",r:"3",key:"dfmy0x"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A=i("Webhook",[["path",{d:"M18 16.98h-5.99c-1.1 0-1.95.94-2.48 1.9A4 4 0 0 1 2 17c.01-.7.2-1.4.57-2",key:"q3hayz"}],["path",{d:"m6 17 3.13-5.78c.53-.97.1-2.18-.5-3.1a4 4 0 1 1 6.89-4.06",key:"1go1hn"}],["path",{d:"m12 6 3.13 5.73C15.66 12.7 16.9 13 18 13a4 4 0 0 1 0 8",key:"qlwsc0"}]]);function K(){return e.jsxs("div",{className:"notice","data-testid":"integration-credential-rule",children:["Credenciais próprias preenchidas e ativas têm prioridade. Quando não houver uma credencial própria ativa, o serviço usa a configuração ativa do backoffice. Se nenhuma estiver disponível, configure a integração antes de usar.",e.jsx("p",{children:"Recebimentos Asaas pela plataforma ficam sujeitos ao repasse pela gestão."})]})}const N={credenciais:{label:"Credenciais",icon:j},configuracoes:{label:"Configurações",icon:C},webhooks:{label:"Webhooks",icon:A},status:{label:"Status",icon:x}},M=[{slug:"claude",title:"Claude",summary:"Leitura automática da placa nas fotos com inteligência artificial.",description:"Leitura automática da placa nas fotos. O uso é cobrado pela Anthropic.",icon:k,tabs:["credenciais","configuracoes","status"]},{slug:"consulta-placa",title:"Consulta de placas",summary:"Marca, modelo, cor e situação do veículo a partir da placa.",description:"Preenchimento de marca, modelo, cor e situação. Requer consultas disponíveis no provedor.",icon:S,tabs:["credenciais","configuracoes","status"]},{slug:"asaas",title:"Asaas",summary:"Cobranças por Pix, boleto e cartão, com conciliação por webhook.",description:"Emita Pix, boleto ou uma fatura para pagamento com cartão. Comece pelo Sandbox para testar sem movimentar dinheiro.",icon:f,tabs:["credenciais","webhooks","status"]}],P=a=>M.find(t=>t.slug===a),O=(a,t)=>a.tabs.find(o=>o===t)??a.tabs[0],u=(a,t)=>[...m.all("configuracoes-integracoes",t),a],h=a=>`/api/v1/configuracoes-integracoes/${a}`;function Q(a){const t=n(s=>d(s.session)),o=p({queryKey:u(a,t),queryFn:({signal:s})=>l(h(a),{signal:s}),enabled:!!t});return{scope:t,query:o}}function T(a){const t=n(s=>d(s.session)),o=y();return v.useCallback(async s=>{const r=await l(h(a),{method:"PUT",body:JSON.stringify(s)});return d(n.getState().session)!==t?!1:(o.setQueryData(u(a,t),r),!0)},[o,t,a])}function q({active:a}){return e.jsx(b,{status:a?"ATIVA":"ENCERRADA",label:a?"Ativada":"Desativada"})}function V({active:a,rows:t,updatedAt:o,updatedBy:s,children:r}){return e.jsxs(e.Fragment,{children:[e.jsxs("dl",{className:"integration-status","data-testid":"integration-status",children:[e.jsxs("div",{children:[e.jsx("dt",{children:"Situação"}),e.jsx("dd",{children:e.jsx(q,{active:a})})]}),t.map(c=>e.jsxs("div",{children:[e.jsx("dt",{children:c.label}),e.jsx("dd",{children:c.value})]},c.label)),e.jsxs("div",{children:[e.jsx("dt",{children:"Última alteração"}),e.jsx("dd",{children:o?g(o):"Nunca configurada"})]}),s!==void 0&&e.jsxs("div",{children:[e.jsx("dt",{children:"Alterado por"}),e.jsx("dd",{children:s||"—"})]})]}),r]})}export{q as A,K as O,V as S,T as a,h as b,P as f,M as i,O as r,N as t,Q as u};
//# sourceMappingURL=StatusSummary-C4v816Te.js.map
