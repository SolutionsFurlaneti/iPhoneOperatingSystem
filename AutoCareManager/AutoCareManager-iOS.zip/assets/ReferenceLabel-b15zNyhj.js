import{bp as c,j as r}from"./index-BMIZgUJd.js";function m({id:e,resource:t,idField:l,labelField:a}){var s;const u=c(t,e!==null);if(e===null)return r.jsx("span",{className:"muted",children:"Avulso"});const n=(s=u.data)==null?void 0:s.find(o=>o[l]===e);return r.jsx("span",{children:n?String(n[a]):"#"+e})}export{m as R};
//# sourceMappingURL=ReferenceLabel-b15zNyhj.js.map
