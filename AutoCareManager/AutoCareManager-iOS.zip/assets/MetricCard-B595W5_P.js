import{h as i,j as e}from"./index-BMIZgUJd.js";import{C as n}from"./Card-DHJFUvnZ.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=i("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]]);function h({label:r,value:s,note:a,icon:t,accent:c}){return e.jsxs(n,{className:"metric-card"+(c?" metric-accent":""),elevation:0,children:[e.jsxs("div",{className:"metric-label",children:[e.jsx("span",{children:r}),t]}),e.jsx("strong",{"data-testid":"metric-"+r,children:s}),e.jsx("span",{className:"metric-note",children:a})]})}export{h as M,x as T};
//# sourceMappingURL=MetricCard-B595W5_P.js.map
