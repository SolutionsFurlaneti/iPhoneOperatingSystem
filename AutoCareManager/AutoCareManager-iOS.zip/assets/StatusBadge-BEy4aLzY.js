import{u as n,j as t}from"./index-CHRx0u_s.js";function u({status:s,label:a}){const{t:e}=n();return t.jsxs("span",{className:"status-badge status-"+s.toLowerCase(),"data-testid":"status-"+s,children:[t.jsx("span",{"aria-hidden":"true"}),e(a)]})}export{u as S};
//# sourceMappingURL=StatusBadge-BEy4aLzY.js.map
