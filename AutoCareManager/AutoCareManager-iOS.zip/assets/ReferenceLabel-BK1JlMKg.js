import{ah as c,j as r}from"./index-5CMBOala.js";function m({id:e,resource:t,idField:a,labelField:l}){var s;const u=c(t,e!==null);if(e===null)return r.jsx("span",{className:"muted",children:"Avulso"});const n=(s=u.data)==null?void 0:s.find(o=>o[a]===e);return r.jsx("span",{children:n?String(n[l]):"#"+e})}export{m as R};
//# sourceMappingURL=ReferenceLabel-BK1JlMKg.js.map
