const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-JUX-hDY7.js","assets/index-BMIZgUJd.js","assets/react-DQarAtJJ.js","assets/charts-DckikGU3.js","assets/index-CHEUjjht.css"])))=>i.map(i=>d[i]);
import{G as e,_ as r}from"./index-BMIZgUJd.js";import"./react-DQarAtJJ.js";import"./charts-DckikGU3.js";const _=e("App",{web:()=>r(()=>import("./web-JUX-hDY7.js"),__vite__mapDeps([0,1,2,3,4])).then(p=>new p.AppWeb)});export{_ as App};
//# sourceMappingURL=index-hqn5M-eN.js.map
