import{ao as c,j as r}from"./index-BB8rq6Q9.js";function m({id:e,resource:t,idField:a,labelField:l}){var s;const o=c(t,e!==null);if(e===null)return r.jsx("span",{className:"muted",children:"Avulso"});const n=(s=o.data)==null?void 0:s.find(u=>u[a]===e);return r.jsx("span",{children:n?String(n[l]):"#"+e})}export{m as R};
//# sourceMappingURL=ReferenceLabel-BhTQId41.js.map
