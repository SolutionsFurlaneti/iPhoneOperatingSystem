const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-D7zwk_zf.js","assets/index-CPx4TUd0.js","assets/react-BaQHJodo.js","assets/charts-Beuk641P.js","assets/index-BbDPihaQ.css"])))=>i.map(i=>d[i]);
import{aS as e,aT as r}from"./index-CPx4TUd0.js";import"./react-BaQHJodo.js";import"./charts-Beuk641P.js";const _=e("App",{web:()=>r(()=>import("./web-D7zwk_zf.js"),__vite__mapDeps([0,1,2,3,4])).then(p=>new p.AppWeb)});export{_ as App};
//# sourceMappingURL=index-C0mIkwvY.js.map
