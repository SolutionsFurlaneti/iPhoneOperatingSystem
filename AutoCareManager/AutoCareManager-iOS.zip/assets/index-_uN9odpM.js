const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BoBhn2v5.js","assets/index-5CMBOala.js","assets/react-4hzvzZwm.js","assets/charts-rr1YMDgM.js","assets/index-CTnZcmaG.css"])))=>i.map(i=>d[i]);
import{aS as e,aT as r}from"./index-5CMBOala.js";import"./react-4hzvzZwm.js";import"./charts-rr1YMDgM.js";const _=e("App",{web:()=>r(()=>import("./web-BoBhn2v5.js"),__vite__mapDeps([0,1,2,3,4])).then(p=>new p.AppWeb)});export{_ as App};
//# sourceMappingURL=index-_uN9odpM.js.map
