import{i as n,u as d,j as e}from"./index-CHRx0u_s.js";import{C as m}from"./Card-Bp5XuIJF.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=n("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]]);function l({label:s,value:a,note:r,icon:c,accent:i}){const{t}=d();return e.jsxs(m,{className:"metric-card"+(i?" metric-accent":""),elevation:0,children:[e.jsxs("div",{className:"metric-label",children:[e.jsx("span",{children:t(s)}),c]}),e.jsx("strong",{"data-testid":"metric-"+s,children:a}),e.jsx("span",{className:"metric-note",children:t(r)})]})}export{l as M,h as T};
//# sourceMappingURL=MetricCard-CAfPJbZP.js.map
