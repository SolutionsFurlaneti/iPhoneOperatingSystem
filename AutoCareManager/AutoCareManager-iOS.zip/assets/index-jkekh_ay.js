const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DDC4NzYO.js","assets/index-DJsQXYa3.js","assets/react-DQarAtJJ.js","assets/charts-B9F2n_6F.js","assets/index-BY21AHvt.css"])))=>i.map(i=>d[i]);
import{G as e,aZ as r}from"./index-DJsQXYa3.js";import"./react-DQarAtJJ.js";import"./charts-B9F2n_6F.js";const _=e("App",{web:()=>r(()=>import("./web-DDC4NzYO.js"),__vite__mapDeps([0,1,2,3,4])).then(p=>new p.AppWeb)});export{_ as App};
//# sourceMappingURL=index-jkekh_ay.js.map
