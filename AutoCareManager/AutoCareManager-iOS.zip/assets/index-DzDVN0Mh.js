const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-ajmt_Dk0.js","assets/index-CHRx0u_s.js","assets/react-DQarAtJJ.js","assets/charts-DckikGU3.js","assets/index-alnHTE-I.css"])))=>i.map(i=>d[i]);
import{I as e,_ as r}from"./index-CHRx0u_s.js";import"./react-DQarAtJJ.js";import"./charts-DckikGU3.js";const _=e("App",{web:()=>r(()=>import("./web-ajmt_Dk0.js"),__vite__mapDeps([0,1,2,3,4])).then(p=>new p.AppWeb)});export{_ as App};
//# sourceMappingURL=index-DzDVN0Mh.js.map
