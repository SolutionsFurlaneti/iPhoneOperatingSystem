import{S as n}from"./dialogs-CxhA1Y49.js";async function u(t,o,r="Confirmar"){return(await n.fire({title:t,text:o,icon:"question",showCancelButton:!0,confirmButtonText:r,cancelButtonText:"Voltar",reverseButtons:!0,focusCancel:!0,customClass:{popup:"confirm-popup"}})).isConfirmed}export{u as c};
//# sourceMappingURL=swal-B4HnzUIG.js.map
