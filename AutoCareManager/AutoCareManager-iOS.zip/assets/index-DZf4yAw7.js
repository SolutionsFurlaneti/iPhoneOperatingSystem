const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-B-HWcml-.js","assets/index-BaXj0Eng.js","assets/react-DQarAtJJ.js","assets/charts-DckikGU3.js","assets/index-BFYO8ROX.css"])))=>i.map(i=>d[i]);
import{G as e,_ as r}from"./index-BaXj0Eng.js";import"./react-DQarAtJJ.js";import"./charts-DckikGU3.js";const _=e("App",{web:()=>r(()=>import("./web-B-HWcml-.js"),__vite__mapDeps([0,1,2,3,4])).then(p=>new p.AppWeb)});export{_ as App};
//# sourceMappingURL=index-DZf4yAw7.js.map
