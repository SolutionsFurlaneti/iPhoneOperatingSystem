const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-ByRZ7-DU.js","assets/index-DsxOOmIM.js","assets/react-BaQHJodo.js","assets/charts-Beuk641P.js","assets/index-DaoTZZDc.css"])))=>i.map(i=>d[i]);
import{aS as e,aT as r}from"./index-DsxOOmIM.js";import"./react-BaQHJodo.js";import"./charts-Beuk641P.js";const _=e("App",{web:()=>r(()=>import("./web-ByRZ7-DU.js"),__vite__mapDeps([0,1,2,3,4])).then(p=>new p.AppWeb)});export{_ as App};
//# sourceMappingURL=index-edKvjEUJ.js.map
