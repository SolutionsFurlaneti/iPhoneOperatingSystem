import{u as i,bp as m,j as t}from"./index-CHRx0u_s.js";function f({id:s,resource:r,idField:u,labelField:a}){var n;const{t:l}=i(),o=m(r,s!==null);if(s===null)return t.jsx("span",{className:"muted",children:l("Avulso")});const e=(n=o.data)==null?void 0:n.find(c=>c[u]===s);return t.jsx("span",{children:e?String(e[a]):"#"+s})}export{f as R};
//# sourceMappingURL=ReferenceLabel-CI6r-M6F.js.map
