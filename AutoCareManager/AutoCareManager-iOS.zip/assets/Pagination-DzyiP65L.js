import{i as c,u as l,j as a,B as o,C as g}from"./index-CHRx0u_s.js";import"./react-DQarAtJJ.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=c("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);function j({page:i,size:d,total:s,onChange:t,busy:n}){const{t:e}=l(),r=Math.max(1,Math.ceil(s/d));return a.jsxs("div",{className:"pagination",children:[a.jsx("span",{children:e(s===1?"{total} registro · Página {page} de {pages}":"{total} registros · Página {page} de {pages}",{total:s,page:i,pages:r})}),a.jsxs("div",{children:[a.jsx(o,{variant:"ghost","aria-label":e("Página anterior"),"data-testid":"page-previous",disabled:i<=1||n,onClick:()=>t(i-1),children:a.jsx(h,{size:18})}),a.jsx(o,{variant:"ghost","aria-label":e("Próxima página"),"data-testid":"page-next",disabled:i>=r||n,onClick:()=>t(i+1),children:a.jsx(g,{size:18})})]})]})}export{j as P};
//# sourceMappingURL=Pagination-DzyiP65L.js.map
