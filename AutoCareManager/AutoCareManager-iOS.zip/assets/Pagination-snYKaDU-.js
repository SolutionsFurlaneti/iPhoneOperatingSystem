import{h as d,j as i,B as r,C as c}from"./index-CLjnIhAG.js";import"./react-4hzvzZwm.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=d("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);function j({page:a,size:o,total:s,onChange:t,busy:e}){const n=Math.max(1,Math.ceil(s/o));return i.jsxs("div",{className:"pagination",children:[i.jsxs("span",{children:[s," registros · Página ",a," de ",n]}),i.jsxs("div",{children:[i.jsx(r,{variant:"ghost","aria-label":"Página anterior","data-testid":"page-previous",disabled:a<=1||e,onClick:()=>t(a-1),children:i.jsx(h,{size:18})}),i.jsx(r,{variant:"ghost","aria-label":"Próxima página","data-testid":"page-next",disabled:a>=n||e,onClick:()=>t(a+1),children:i.jsx(c,{size:18})})]})]})}export{j as P};
//# sourceMappingURL=Pagination-snYKaDU-.js.map
