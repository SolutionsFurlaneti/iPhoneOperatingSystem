const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DKHpHraR.js","assets/index-BmTGR7kS.js","assets/react-DQarAtJJ.js","assets/charts-DckikGU3.js","assets/index-BFYO8ROX.css"])))=>i.map(i=>d[i]);
import{G as e,_ as r}from"./index-BmTGR7kS.js";import"./react-DQarAtJJ.js";import"./charts-DckikGU3.js";const _=e("App",{web:()=>r(()=>import("./web-DKHpHraR.js"),__vite__mapDeps([0,1,2,3,4])).then(p=>new p.AppWeb)});export{_ as App};
//# sourceMappingURL=index-SJ81_Fre.js.map
