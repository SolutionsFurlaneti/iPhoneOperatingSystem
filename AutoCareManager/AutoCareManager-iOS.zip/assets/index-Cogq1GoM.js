const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BU30x_Vb.js","assets/index-DQlVdS2B.js","assets/react-DQarAtJJ.js","assets/charts-B9F2n_6F.js","assets/index-BY21AHvt.css"])))=>i.map(i=>d[i]);
import{aW as e,aX as r}from"./index-DQlVdS2B.js";import"./react-DQarAtJJ.js";import"./charts-B9F2n_6F.js";const _=e("App",{web:()=>r(()=>import("./web-BU30x_Vb.js"),__vite__mapDeps([0,1,2,3,4])).then(p=>new p.AppWeb)});export{_ as App};
//# sourceMappingURL=index-Cogq1GoM.js.map
