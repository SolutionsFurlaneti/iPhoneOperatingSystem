const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CgOomhl5.js","assets/index-BqaZhbtR.js","assets/react-DQarAtJJ.js","assets/charts-B9F2n_6F.js","assets/index-yY4fBUjX.css"])))=>i.map(i=>d[i]);
import{G as e,_ as r}from"./index-BqaZhbtR.js";import"./react-DQarAtJJ.js";import"./charts-B9F2n_6F.js";const _=e("App",{web:()=>r(()=>import("./web-CgOomhl5.js"),__vite__mapDeps([0,1,2,3,4])).then(p=>new p.AppWeb)});export{_ as App};
//# sourceMappingURL=index-BzZYpYp-.js.map
