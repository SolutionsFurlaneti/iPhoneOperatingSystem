function o(t){if(t)try{const r=new URL(t);return r.protocol==="https:"&&!r.username&&!r.password?r.href:void 0}catch{return}}export{o as s};
