(() => {
  const signupPath = document.currentScript.dataset.whatsappSignupPath.toLowerCase();
  const { pathname, search, hash } = window.location;
  let decodedPath = pathname;
  try {
    decodedPath = decodeURI(pathname);
  } catch {
    // A malformed URI cannot match the sign-up page.
  }
  if (decodedPath.replace(/\/+$/, '').toLowerCase() === signupPath) {
    const leadToken = /^#lead=([a-f0-9]{32})$/i.exec(hash)?.[1];
    if (hash) window.history.replaceState(window.history.state, '', pathname + search);
    // main.tsx removes this handoff before mounting React.
    window.nextTimeSlotWhatsAppSignupLead = leadToken;
    return;
  }
  // Google tags are loaded by the public landing only after an explicit cookie choice.
})();
