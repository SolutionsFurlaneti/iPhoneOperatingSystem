(() => {
  const signupPath = document.currentScript.dataset.whatsappSignupPath.toLowerCase();
  const { pathname, search, hash } = window.location;
  let decodedPath = pathname;
  try {
    decodedPath = decodeURI(pathname);
  } catch {
    // A malformed URI cannot match the sign-up page.
  }
  if (decodedPath.replace(/\/+$/, '').toLowerCase() === signupPath) {
    const leadToken = /^#lead=([a-f0-9]{32})$/i.exec(hash)?.[1];
    if (hash) window.history.replaceState(window.history.state, '', pathname + search);
    // main.tsx removes this handoff before mounting React.
    window.nextTimeSlotWhatsAppSignupLead = leadToken;
    return;
  }

  window.dataLayer = window.dataLayer || [];
  window.gtag = function () { window.dataLayer.push(arguments); };
  window.gtag('js', new Date());
  window.gtag('config', 'GTM-PXXVKW2Q');

  const tag = document.createElement('script');
  tag.async = true;
  tag.src = 'https://www.googletagmanager.com/gtm.js?id=GTM-PXXVKW2Q';
  document.head.append(tag);
})();
