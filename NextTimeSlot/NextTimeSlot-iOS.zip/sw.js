const BASE_PATH = new URL(self.registration.scope).pathname;
const CACHE_PREFIX = `nexttimeslot-shell:${BASE_PATH}:`;
const CACHE_NAME = `${CACHE_PREFIX}v1`;
const APP_SHELL = ['', 'manifest.webmanifest', 'icon.svg'].map((path) => `${BASE_PATH}${path}`);

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) =>
    (key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME) || (BASE_PATH === '/' && key === 'nexttimeslot-shell-v1'),
  ).map((key) => caches.delete(key)))));
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin
      || !url.pathname.startsWith(BASE_PATH) || url.pathname.startsWith(`${BASE_PATH}api/`)) return;
  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(() => caches.match(BASE_PATH)));
    return;
  }
  if (APP_SHELL.includes(url.pathname)) {
    event.respondWith(caches.match(request).then((cached) => cached || fetch(request)));
  }
});
